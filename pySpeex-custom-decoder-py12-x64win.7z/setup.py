from setuptools import setup, Extension

from Cython.Build import cythonize


ext = Extension(
        name="speex",
        sources=["speex.pyx"],
        include_dirs=["/usr/include/speex", "/usr/local/include/speex", "/usr/include", "D:\\pySpeex\\include\\speex"],
        libraries=["speex"],
        )

setup(name="speex",
      version="1.0",
      description="Python interface to the Speex audio Codec",
      ext_modules=cythonize(
          ext, language_level="3",
          )
      )
